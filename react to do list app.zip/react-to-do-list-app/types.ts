
export enum Priority {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
}

export enum Category {
  WORK = 'Work',
  PERSONAL = 'Personal',
  SHOPPING = 'Shopping',
  HEALTH = 'Health',
  STUDY = 'Study',
}

export type Task = {
  id: string;
  title: string;
  dueDate: string;
  priority: Priority;
  category: Category;
  completed: boolean;
};

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark',
}

export enum AccentColor {
  CYAN = 'cyan',
  BLUE = 'blue',
  PINK = 'pink',
  ORANGE = 'orange',
}

export type SortOrder = 'asc' | 'desc';
