import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { TaskList } from './components/TaskList';
import { FloatingActionButton } from './components/FloatingActionButton';
import { TaskModal } from './components/TaskModal';
import { SettingsModal } from './components/SettingsModal';
import { useLocalStorage } from './hooks/useLocalStorage';
// Use relative path for ThemeContext to ensure browser compatibility without path aliases.
import { useTheme } from './contexts/ThemeContext';
import type { Task, SortOrder } from './types';
import { AccentColor } from './types';
import { DUMMY_TASKS } from './constants';

const App: React.FC = () => {
  const [tasks, setTasks] = useLocalStorage<Task[]>('tasks', []);
  const [isTaskModalOpen, setTaskModalOpen] = useState(false);
  const [isSettingsModalOpen, setSettingsModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const { accentColor } = useTheme();

  useEffect(() => {
    // Load dummy tasks if local storage is empty
    if (tasks.length === 0) {
      setTasks(DUMMY_TASKS);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  useEffect(() => {
    const root = document.documentElement;
    const accentColorMap: Record<AccentColor, string> = {
        [AccentColor.CYAN]: '6 182 212',
        [AccentColor.BLUE]: '59 130 246',
        [AccentColor.PINK]: '236 72 153',
        [AccentColor.ORANGE]: '249 115 22',
    };
    root.style.setProperty('--accent-color-rgb', accentColorMap[accentColor]);
  }, [accentColor]);

  const handleOpenAddTaskModal = () => {
    setTaskToEdit(null);
    setTaskModalOpen(true);
  };

  const handleOpenEditTaskModal = (task: Task) => {
    setTaskToEdit(task);
    setTaskModalOpen(true);
  };

  const handleCloseTaskModal = () => {
    setTaskModalOpen(false);
    setTaskToEdit(null);
  };

  const handleSaveTask = (task: Task) => {
    if (taskToEdit) {
      setTasks(tasks.map((t) => (t.id === task.id ? task : t)));
    } else {
      setTasks([...tasks, task]);
    }
    handleCloseTaskModal();
  };

  const handleToggleComplete = (taskId: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(tasks.filter((task) => task.id !== taskId));
  };
  
  const handleSortToggle = () => {
    setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
  };

  const accentColorClasses: Record<AccentColor, string> = {
    [AccentColor.CYAN]: 'from-cyan-500 to-blue-500',
    [AccentColor.BLUE]: 'from-blue-500 to-indigo-500',
    [AccentColor.PINK]: 'from-pink-500 to-rose-500',
    [AccentColor.ORANGE]: 'from-orange-500 to-amber-500',
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-slate-200 transition-colors duration-300 font-sans">
      <div className={`absolute top-0 left-0 w-full h-96 bg-gradient-to-br ${accentColorClasses[accentColor]} rounded-b-3xl opacity-20 dark:opacity-30`}></div>
      <div className="relative min-h-screen flex flex-col items-center p-4 sm:p-6 md:p-8">
        <div className="w-full max-w-3xl mx-auto">
          <Header onSettingsClick={() => setSettingsModalOpen(true)} />
          <main className="mt-8">
            <TaskList
              tasks={tasks}
              onToggleComplete={handleToggleComplete}
              onDelete={handleDeleteTask}
              onEdit={handleOpenEditTaskModal}
              sortOrder={sortOrder}
              onSortToggle={handleSortToggle}
            />
          </main>
        </div>
      </div>
      <FloatingActionButton onClick={handleOpenAddTaskModal} />
      {isTaskModalOpen && (
        <TaskModal
          isOpen={isTaskModalOpen}
          onClose={handleCloseTaskModal}
          onSave={handleSaveTask}
          taskToEdit={taskToEdit}
        />
      )}
      {isSettingsModalOpen && (
        <SettingsModal isOpen={isSettingsModalOpen} onClose={() => setSettingsModalOpen(false)} />
      )}
    </div>
  );
};

export default App;