
import type { Task } from './types';
import { Priority, Category } from './types';

export const CATEGORIES = [
  { id: Category.WORK, name: 'Work', color: 'bg-blue-500' },
  { id: Category.PERSONAL, name: 'Personal', color: 'bg-green-500' },
  { id: Category.SHOPPING, name: 'Shopping', color: 'bg-yellow-500' },
  { id: Category.HEALTH, name: 'Health', color: 'bg-red-500' },
  { id: Category.STUDY, name: 'Study', color: 'bg-purple-500' },
];

export const PRIORITIES = [
  { id: Priority.LOW, name: 'Low', color: 'bg-green-500' },
  { id: Priority.MEDIUM, name: 'Medium', color: 'bg-yellow-500' },
  { id: Priority.HIGH, name: 'High', color: 'bg-red-500' },
];

export const DUMMY_TASKS: Task[] = [
  {
    id: '1',
    title: 'Finish Q3 report for marketing',
    dueDate: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split('T')[0],
    priority: Priority.HIGH,
    category: Category.WORK,
    completed: false,
  },
  {
    id: '2',
    title: 'Buy groceries for the week',
    dueDate: new Date().toISOString().split('T')[0],
    priority: Priority.MEDIUM,
    category: Category.SHOPPING,
    completed: false,
  },
  {
    id: '3',
    title: 'Go for a 30-minute run',
    dueDate: new Date().toISOString().split('T')[0],
    priority: Priority.LOW,
    category: Category.HEALTH,
    completed: true,
  },
    {
    id: '4',
    title: 'Read chapter 5 of React documentation',
    dueDate: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split('T')[0],
    priority: Priority.MEDIUM,
    category: Category.STUDY,
    completed: false,
  },
];
