
import React from 'react';
import { PlusIcon } from './Icons';
import { useTheme } from '../contexts/ThemeContext';
// FIX: `AccentColor` is used as a value for object keys, so it must be imported as a value, not a type.
import { AccentColor } from '../types';

interface FloatingActionButtonProps {
  onClick: () => void;
}

export const FloatingActionButton: React.FC<FloatingActionButtonProps> = ({ onClick }) => {
  const { accentColor } = useTheme();
  
  const accentColorClasses: Record<AccentColor, { bg: string; shadow: string }> = {
    [AccentColor.CYAN]: { bg: 'bg-accent-cyan', shadow: 'shadow-[0_0_20px_theme(colors.cyan.500)]' },
    [AccentColor.BLUE]: { bg: 'bg-accent-blue', shadow: 'shadow-[0_0_20px_theme(colors.blue.500)]' },
    [AccentColor.PINK]: { bg: 'bg-accent-pink', shadow: 'shadow-[0_0_20px_theme(colors.pink.500)]' },
    [AccentColor.ORANGE]: { bg: 'bg-accent-orange', shadow: 'shadow-[0_0_20px_theme(colors.orange.500)]' },
  };

  const currentAccent = accentColorClasses[accentColor];

  return (
    <button
      onClick={onClick}
      className={`fixed bottom-8 right-8 w-16 h-16 rounded-full text-white flex items-center justify-center shadow-lg transform transition-all duration-300 hover:scale-110 hover:rotate-12 focus:outline-none focus:ring-4 focus:ring-opacity-50 ${currentAccent.bg} ${currentAccent.shadow.replace('theme(colors.cyan.500)', 'currentColor').replace('theme(colors.blue.500)', 'currentColor').replace('theme(colors.pink.500)', 'currentColor').replace('theme(colors.orange.500)', 'currentColor')}`}
      aria-label="Add new task"
    >
      <PlusIcon className="w-8 h-8" />
    </button>
  );
};
