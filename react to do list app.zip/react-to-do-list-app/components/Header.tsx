
import React from 'react';
import { SettingsIcon } from './Icons';

interface HeaderProps {
  onSettingsClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  const date = new Date();
  const dateString = date.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <header className="flex justify-between items-center">
      <div>
        <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">To-Do List</h1>
        <p className="text-sm sm:text-md text-white/80 mt-1">{dateString}</p>
      </div>
      <button
        onClick={onSettingsClick}
        className="p-2 rounded-full text-white/80 hover:bg-white/20 hover:text-white transition-colors duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
        aria-label="Open settings"
      >
        <SettingsIcon className="w-6 h-6" />
      </button>
    </header>
  );
};
