import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import { useTheme } from '../contexts/ThemeContext';
import { CloseIcon } from './Icons';
import { Theme, AccentColor } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { theme, setTheme, accentColor, setAccentColor } = useTheme();
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  if (!isOpen) return null;
  
  const accentColors: {id: AccentColor; color: string}[] = [
      { id: AccentColor.CYAN, color: 'bg-accent-cyan' },
      { id: AccentColor.BLUE, color: 'bg-accent-blue' },
      { id: AccentColor.PINK, color: 'bg-accent-pink' },
      { id: AccentColor.ORANGE, color: 'bg-accent-orange' },
  ]

  return ReactDOM.createPortal(
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md p-6 relative animate-slide-up">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors"
          aria-label="Close settings"
        >
          <CloseIcon className="w-5 h-5" />
        </button>
        <h2 className="text-2xl font-bold mb-6">Settings</h2>
        
        <div className="space-y-6">
          {/* Theme Toggle */}
          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Theme</label>
            <div className="flex items-center space-x-2 bg-slate-200 dark:bg-slate-700 rounded-lg p-1">
              <button
                onClick={() => setTheme(Theme.LIGHT)}
                className={`flex-1 py-1.5 text-sm rounded-md transition-colors ${theme === Theme.LIGHT ? 'bg-white dark:bg-slate-500 shadow' : ''}`}
              >
                Light
              </button>
              <button
                onClick={() => setTheme(Theme.DARK)}
                className={`flex-1 py-1.5 text-sm rounded-md transition-colors ${theme === Theme.DARK ? 'bg-white dark:bg-slate-500 shadow' : ''}`}
              >
                Dark
              </button>
            </div>
          </div>
          
          {/* Accent Color Picker */}
          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Accent Color</label>
            <div className="flex items-center space-x-3">
              {accentColors.map(({id, color}) => (
                <button
                  key={id}
                  onClick={() => setAccentColor(id)}
                  className={`w-10 h-10 rounded-full ${color} transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800 ${accentColor === id ? `ring-2 ring-offset-2 dark:ring-offset-slate-800 ring-${id}-500` : ''}`}
                  aria-label={`Set accent color to ${id}`}
                ></button>
              ))}
            </div>
          </div>
          
          {/* Notification Preferences */}
          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-2">Notifications</label>
            <div className="flex items-center justify-between bg-slate-200 dark:bg-slate-700 p-3 rounded-lg">
                <span>Enable due date reminders</span>
                 <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                    <input
                      type="checkbox"
                      name="toggle"
                      id="toggle"
                      className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"
                      checked={notificationsEnabled}
                      onChange={() => setNotificationsEnabled(!notificationsEnabled)}
                    />
                    <label htmlFor="toggle" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
                </div>
            </div>
            <p className="text-xs text-slate-400 mt-2">Note: Web notifications are for demonstration purposes only.</p>
          </div>
        </div>
      </div>
       <style>{`
        .toggle-checkbox {
          transition: right 0.2s ease-in-out;
        }
        .toggle-checkbox:checked {
          right: 0;
          border-color: rgb(var(--accent-color-rgb));
        }
        .toggle-checkbox:checked + .toggle-label {
          background-color: rgb(var(--accent-color-rgb));
        }
      `}</style>
    </div>,
    document.getElementById('modal-root')!
  );
};
