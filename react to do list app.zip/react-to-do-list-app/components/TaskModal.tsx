
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { CloseIcon } from './Icons';
import type { Task } from '../types';
// FIX: `AccentColor` is used as a value for object keys, so it must be imported as a value, not a type.
import { Priority, Category, AccentColor } from '../types';
import { CATEGORIES, PRIORITIES } from '../constants';
import { useTheme } from '../contexts/ThemeContext';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Task) => void;
  taskToEdit: Task | null;
}

export const TaskModal: React.FC<TaskModalProps> = ({ isOpen, onClose, onSave, taskToEdit }) => {
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<Priority>(Priority.MEDIUM);
  const [category, setCategory] = useState<Category>(Category.PERSONAL);
  const { accentColor } = useTheme();

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title);
      setDueDate(taskToEdit.dueDate);
      setPriority(taskToEdit.priority);
      setCategory(taskToEdit.category);
    } else {
      setTitle('');
      setDueDate(new Date().toISOString().split('T')[0]);
      setPriority(Priority.MEDIUM);
      setCategory(Category.PERSONAL);
    }
  }, [taskToEdit, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave({
      id: taskToEdit ? taskToEdit.id : new Date().toISOString(),
      title,
      dueDate,
      priority,
      category,
      completed: taskToEdit ? taskToEdit.completed : false,
    });
  };

  const accentColorClasses: Record<AccentColor, { bg: string; ring: string; shadow: string }> = {
    [AccentColor.CYAN]: { bg: 'bg-accent-cyan', ring: 'focus:ring-accent-cyan', shadow: 'shadow-cyan-500/50' },
    [AccentColor.BLUE]: { bg: 'bg-accent-blue', ring: 'focus:ring-accent-blue', shadow: 'shadow-blue-500/50' },
    [AccentColor.PINK]: { bg: 'bg-accent-pink', ring: 'focus:ring-accent-pink', shadow: 'shadow-pink-500/50' },
    [AccentColor.ORANGE]: { bg: 'bg-accent-orange', ring: 'focus:ring-accent-orange', shadow: 'shadow-orange-500/50' },
  };
  const currentAccent = accentColorClasses[accentColor];


  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md p-6 relative animate-slide-up">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors"
          aria-label="Close modal"
        >
          <CloseIcon className="w-5 h-5" />
        </button>
        <h2 className="text-2xl font-bold mb-6">{taskToEdit ? 'Edit Task' : 'Add New Task'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Title</label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={`w-full bg-slate-200 dark:bg-slate-700 border-transparent rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${currentAccent.ring}`}
              required
            />
          </div>
          <div>
            <label htmlFor="dueDate" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Due Date</label>
            <input
              type="date"
              id="dueDate"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className={`w-full bg-slate-200 dark:bg-slate-700 border-transparent rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${currentAccent.ring}`}
              required
            />
          </div>
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Category</label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className={`w-full bg-slate-200 dark:bg-slate-700 border-transparent rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${currentAccent.ring}`}
            >
              {CATEGORIES.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 dark:text-slate-300 mb-1">Priority</label>
            <div className="flex space-x-2">
              {PRIORITIES.map(p => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => setPriority(p.id)}
                  className={`flex-1 py-2 text-sm rounded-lg transition-all duration-200 ${
                    priority === p.id 
                      ? `${p.color} text-white font-semibold shadow-md` 
                      : 'bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600'
                  }`}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>
          <div className="pt-4">
            <button
              type="submit"
              className={`w-full py-3 px-4 rounded-lg text-white font-semibold transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 dark:focus:ring-offset-slate-800 ${currentAccent.bg} ${currentAccent.ring} shadow-lg ${currentAccent.shadow}`}
            >
              {taskToEdit ? 'Save Changes' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>,
    document.getElementById('modal-root')!
  );
};
