import React from 'react';
import { TaskCard } from './TaskCard';
import type { Task, SortOrder } from '../types';
import { SortAscIcon, SortDescIcon } from './Icons';

interface TaskListProps {
  tasks: Task[];
  onToggleComplete: (taskId: string) => void;
  onDelete: (taskId: string) => void;
  onEdit: (task: Task) => void;
  sortOrder: SortOrder;
  onSortToggle: () => void;
}

export const TaskList: React.FC<TaskListProps> = ({ tasks, onToggleComplete, onDelete, onEdit, sortOrder, onSortToggle }) => {
  const pendingTasks = tasks.filter((task) => !task.completed);
  const completedTasks = tasks.filter((task) => task.completed);
  
  const sortTasks = (tasksToSort: Task[]): Task[] => {
    return [...tasksToSort].sort((a, b) => {
      const dateA = new Date(a.dueDate).getTime();
      const dateB = new Date(b.dueDate).getTime();
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
    });
  };

  const sortedPendingTasks = sortTasks(pendingTasks);
  const sortedCompletedTasks = sortTasks(completedTasks);

  return (
    <div className="space-y-8">
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300">To-Do</h2>
          <button
            onClick={onSortToggle}
            className="flex items-center space-x-2 text-sm text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-colors p-1 rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            aria-label={`Sort by due date ${sortOrder === 'asc' ? 'descending' : 'ascending'}`}
          >
            <span>Due Date</span>
            {sortOrder === 'asc' ? <SortAscIcon className="w-4 h-4" /> : <SortDescIcon className="w-4 h-4" />}
          </button>
        </div>
        
        {sortedPendingTasks.length > 0 ? (
          <div className="space-y-4">
            {sortedPendingTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onToggleComplete={onToggleComplete}
                onDelete={onDelete}
                onEdit={onEdit}
              />
            ))}
          </div>
        ) : (
          <p className="text-center text-slate-500 dark:text-slate-400 py-4">No pending tasks. Great job!</p>
        )}
      </div>

      {sortedCompletedTasks.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-4 text-slate-700 dark:text-slate-300">Completed</h2>
          <div className="space-y-4">
            {sortedCompletedTasks.map((task) => (
              <TaskCard
                key={task.id}
                task={task}
                onToggleComplete={onToggleComplete}
                onDelete={onDelete}
                onEdit={onEdit}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};