
import React from 'react';
import { EditIcon, TrashIcon, CategoryIcon } from './Icons';
import type { Task } from '../types';
import { CATEGORIES, PRIORITIES } from '../constants';
import { useTheme } from '../contexts/ThemeContext';
import type { AccentColor } from '../types';

interface TaskCardProps {
  task: Task;
  onToggleComplete: (taskId: string) => void;
  onDelete: (taskId: string) => void;
  onEdit: (task: Task) => void;
}

const AnimatedCheckmark: React.FC<{ completed: boolean }> = ({ completed }) => {
  const { accentColor } = useTheme();
  const accentColorHex: Record<AccentColor, string> = {
      cyan: '#06b6d4',
      blue: '#3b82f6',
      pink: '#ec4899',
      orange: '#f97316',
  };

  return (
    <svg
      className={`w-6 h-6 transition-all duration-300 ${completed ? `stroke-[${accentColorHex[accentColor]}]` : 'stroke-slate-400'}`}
      viewBox="0 0 24 24"
      fill="none"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path
        className="checkmark__circle"
        d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
        style={{
          strokeDasharray: 100,
          strokeDashoffset: completed ? 0 : 100,
          transition: 'stroke-dashoffset 0.5s ease-in-out',
        }}
      />
      <path
        className="checkmark__check"
        d="M9 12l2 2 4-4"
        style={{
          strokeDasharray: 10,
          strokeDashoffset: completed ? 0 : 10,
          transition: 'stroke-dashoffset 0.4s ease-in-out 0.2s',
        }}
      />
    </svg>
  );
};


export const TaskCard: React.FC<TaskCardProps> = ({ task, onToggleComplete, onDelete, onEdit }) => {
  const category = CATEGORIES.find(c => c.id === task.category);
  const priority = PRIORITIES.find(p => p.id === task.priority);

  return (
    <div
      className={`bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm p-4 rounded-xl shadow-md dark:shadow-black/20 transition-all duration-300 flex items-start space-x-4 ${
        task.completed ? 'opacity-60' : ''
      }`}
    >
      <button onClick={() => onToggleComplete(task.id)} className="flex-shrink-0 mt-1" aria-label="Toggle task completion">
        <AnimatedCheckmark completed={task.completed} />
      </button>

      <div className="flex-grow">
        <p className={`font-semibold ${task.completed ? 'line-through text-slate-500 dark:text-slate-400' : ''}`}>
          {task.title}
        </p>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
          <div className="flex items-center space-x-1">
             <CategoryIcon category={task.category} className="w-3.5 h-3.5" />
            <span>{category?.name}</span>
          </div>
          <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
          <div className="flex items-center space-x-1.5">
            <span className={`w-2.5 h-2.5 rounded-full ${priority?.color}`}></span>
            <span>{priority?.name}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center space-x-2 flex-shrink-0">
        <button onClick={() => onEdit(task)} className="p-1.5 text-slate-500 hover:text-blue-500 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" aria-label="Edit task">
          <EditIcon className="w-5 h-5" />
        </button>
        <button onClick={() => onDelete(task.id)} className="p-1.5 text-slate-500 hover:text-red-500 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" aria-label="Delete task">
          <TrashIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
